import { useState } from "react";
import styles from "./styles.module.css";
import polmanLogo from "../../assets/logoPolman.png"; // Logo Polman
import jumlahBarangIcon from "../../assets/jumlah_barang_icon.png"; // Ikon untuk Jumlah Barang
import pengaturanRpmIcon from "../../assets/pengaturan_rpm_icon.png"; // Ikon untuk Pengaturan RPM

const Dashboard = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className={styles.dashboard_container}>
      {/* Sidebar */}
      <aside
        className={`${styles.sidebar} ${
          isSidebarOpen ? styles.sidebar_open : styles.sidebar_closed
        }`}
      >
        <div className={styles.logo_section}>
          {isSidebarOpen ? (
            <h2 className={styles.logo_text}>Sistem Monitoring</h2>
          ) : (
            <img src={polmanLogo} alt="Polman Logo" className={styles.logo_image} />
          )}
        </div>
        <ul className={styles.sidebar_menu}>
          <li className={styles.menu_item}>
            {isSidebarOpen ? (
              "Jumlah Barang"
            ) : (
              <img
                src={jumlahBarangIcon}
                alt="Jumlah Barang"
                className={styles.menu_icon}
              />
            )}
          </li>
          <li className={styles.menu_item}>
            {isSidebarOpen ? (
              "Pengaturan RPM"
            ) : (
              <img
                src={pengaturanRpmIcon}
                alt="Pengaturan RPM"
                className={styles.menu_icon}
              />
            )}
          </li>
        </ul>
      </aside>

      {/* Main Content */}
      <div className={styles.main_content}>
        <nav className={styles.navbar}>
          <button className={styles.toggle_btn} onClick={toggleSidebar}>
            {isSidebarOpen ? "←" : "→"}
          </button>
          <h1>Dashboard</h1>
        </nav>

        <div className={styles.content_area}>
		{/* ATASAN KARTU */}
		<div className={styles.data_section}>
			<div className={styles.data_card}>
				<h3>Jawa Timur</h3>
				{/* Tempat grafik */}
			</div>
			<div className={styles.data_card}>
				<h3>Jawa Barat</h3>
				{/* Tempat tabel */}
			</div>
        </div>
		<div className={styles.header_cards}>
		{/* ANGKA JAWA TIMUR */}
		<div className={styles.card}>
			<div className={styles.card_body}>
			<p>23</p>
			</div>
		</div>
		{/* ANGKA JAWA TIMUR */}
		{/* <div className={styles.card}>
			<h3>Order untuk Dikirim</h3>
			<p>0.00</p>
			<a href="#">Lihat Detail</a>
		</div> */}
		{/* ANGKA JAWA KOTA BANDUNG */}
		<div className={styles.card}>
			<div className={styles.card_body}>
			<p>23</p>
			</div>
		</div>
		{/* ANGKA JAWA KOTA BANDUNG */}
		</div>
		{/* ANGKA JAWA KOTA TASIKMALAYA */}
		<div className={styles.card}>
			<div className={styles.card_body}>
			<p>23</p>
			</div>
		</div>
		{/* ANGKA JAWA KOTA TASIKMALAYA */}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
